var food = [
    {
        "name": "The Fire Burger",
        "kCal": 750,
        "lactose": true,
        "gluten": true,    
        "img": "https://order.redrobinpa.com/usercontent/product_sub_img/Bacon_Chsburger_Burger.png"
    },

    {
        "name": "Fried Turkey Burger",
        "kCal": 600,
        "lactose": true,
        "gluten": false,
        "img": "https://www.menshealth.com.sg/sites/default/files/oimg/shared/weightloss-nutrition/CharbroiledTurkey_CJ.jpg"
    },

    {
        "name": "A Double w/Cheese",
        "kCal": 1800,
        "lactose": true,
        "gluten": true,
        "img": "https://www.chewboom.com/wp-content/uploads/2016/05/Carl%E2%80%99s-Jr.-debuts-the-California-Classic-Double-Cheeseburger-nationwide-678x381.jpg"
    }
]
